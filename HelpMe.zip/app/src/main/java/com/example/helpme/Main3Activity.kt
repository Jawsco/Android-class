package com.example.helpme

import android.graphics.BitmapFactory
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main3.*
import java.io.InputStream
import java.net.URL

class Main3Activity : AppCompatActivity()
{

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        button7.setOnClickListener { view ->
            ThreadClass().start()
        }

        button8.setOnClickListener { view ->
            finish()
        }
    }

    inner class ThreadClass : Thread()
    {
        override fun run()
        {
            var idx : Int = 0

            when(idx++)
            {
                0->
                {val url = "D:/Desktop/coding/Android Projects/HelpMe/app/src/main/res/drawable-v24/a.jpg"
                    var bitmap = BitmapFactory.decodeStream(URL(url).content as InputStream)}

                1->
                {}
                    val url2 = "D:/Desktop/coding/Android Projects/HelpMe/app/src/main/res/drawable-v24/b.jpg"
                2->{}
                    val url3 = "D:/Desktop/coding/Android Projects/HelpMe/app/src/main/res/drawable-v24/c.jpg"
                3->{}
                    val url4 = "D:/Desktop/coding/Android Projects/HelpMe/app/src/main/res/drawable-v24/d.jpg"
                4->{}
                    val url5 = "D:/Desktop/coding/Android Projects/HelpMe/app/src/main/res/drawable-v24/e.jpg"
                5->{}
                    val url6 = "D:/Desktop/coding/Android Projects/HelpMe/app/src/main/res/drawable-v24/f.jpg"
                6->{}
                    val url7 = "D:/Desktop/coding/Android Projects/HelpMe/app/src/main/res/drawable-v24/g.jpg"
                7->{}
                    val url8 = "D:/Desktop/coding/Android Projects/HelpMe/app/src/main/res/drawable-v24/h.jpg"
                8->{}
                    val url9 = "D:/Desktop/coding/Android Projects/HelpMe/app/src/main/res/drawable-v24/i.jpg"
            }

            runOnUiThread{

                imageView.setImageBitmap(bitmap)

            }
        }
    }

    override fun onDestroy()
    {
        super.onDestroy()
    }
}
